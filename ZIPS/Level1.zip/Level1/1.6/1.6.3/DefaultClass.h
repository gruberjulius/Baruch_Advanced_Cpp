class DefaultClass
{
private:
	int val;
};

