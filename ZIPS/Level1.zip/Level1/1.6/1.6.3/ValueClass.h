class ValueClass
{
private:
	int val;
public:
	ValueClass() { 
		val = 0; 
		std::cout << "Value Class" << std::endl;
	};
};

