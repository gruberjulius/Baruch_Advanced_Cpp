g++ -std=c++14 -Wunused-value Level4_Section2_Exercise5.cpp
